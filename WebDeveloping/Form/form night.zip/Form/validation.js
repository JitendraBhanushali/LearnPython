var isvalid = true;
var isemailValid = true;

$( document ).ready(function() {
    console.log( "ready!" );
    showTableData();
});


// This is a Validation Checker
$(".submitform.form-control").click(function () {

    var validation = $("#validation");

    validation.validate({
        rules: {
            fname: {
                required: true,
                lattersonly: true
            },
            lname: {
                required: true,
                lattersonly: true
            },
            email: {
                required: true,
                email: true
            },
            mobile: {
                required: true,
                numericonly: true,
                minlength: 10,
                maxlength: 13
            },
            gender: {
                required: true
            },
            adrs: {
                required: true
            },
            country: {
                required: true
            },
            ststes: {
                required: true
            }


        },
        messages: {
            fname: {
                required: 'First Name must be required',
                lattersonly: 'Invalid Name'
            },
            lname: {
                required: 'Last Name must be required',
                lattersonly: 'Invalid Last Name'
            },
            email: {
                required: 'Email must be required',
                email: 'Email Invalid'

            },
            mobile: {
                required: 'Mobile must be required',
                numericonly: 'Enter Valid Number',
                minlength: 'Min 10 digits',
                maxlength: 'Max 13 digits'
            },
            gender: {
                required: 'Gender must be required'
            },
            adrs: {
                required: 'Address must be required'
            },
            country: {
                required: 'Country must be required'
            },
            ststes: {
                required: 'states must be required'
            }

        },
        errorPlacement: function (error, element) {
            if (element.is(":radio")) {
                error.appendTo(element.parents(".gen"));
            } else {
                error.insertAfter(element);
            }
        },
        // errorPlacement:function(error,element){
        //     if(element.is(":checkbox")){
        //         error.appendTo(element.parents(".hob"));
        //     }else{
        //         error.insertAfter(element);
        //     }
        // }

    });


    isvalid = $("#validation").valid();
    console.log('isvalid :: ', isvalid);


    jQuery.validator.addMethod('lattersonly', function (value, element) {
        return /^[^-\s][a-zA-Z_\s-]+$/.test(value);
    });

    jQuery.validator.addMethod('numericonly', function (value, element) {
        return /^[+0-9]+$/.test(value);
    });

    jQuery.validator.addMethod('all', function (value, element) {
        return /^[^-\s][a-zA-Z0-9_\s-]+$/.test(value);
    });

});

// Creating a State list

var countryList = {

    India: ['', 'Gujrat', 'Panjab', 'Delhi', 'Maharashtra', 'Rajashthan'],
    Austrailya: ['', 'Aus', 'New South Wales', 'Queensland', 'South Australia', 'Tasmania'],
    UAE: ['', 'Dubai', 'Abu Dhabi', 'Sharjah'],
    UK: ['', 'Scotland', 'Northern Ireland', 'Wales', 'Northern Ireland']
}

country = document.getElementById("country"); //parent select element
states = document.getElementById("states"); //child select element

for (key in countryList) { //populate the parent select element with array key
    country.innerHTML = country.innerHTML + '<option>' + key + '</option>';
}

country.addEventListener('change', function populate_child(e) {
    states.innerHTML = '';
    itm = e.target.value;
    if (itm in countryList) {
        for (i = 0; i < countryList[itm].length; i++) {
            states.innerHTML = states.innerHTML + '<option>' + countryList[itm][i] + '</option>';
        }
    }
});

// Create a main Insert Function

function insert() {


    var fname = document.getElementById('fname').value;
    var lname = document.getElementById('lname').value;
    var email = document.getElementById('email').value;
    var mobile = document.getElementById('mobile').value;
    var gender = document.querySelector('input[name="gender"]:checked').value;
    var adrs = document.getElementById('adrs').value;
    var country = document.getElementById('country').value;
    var states = document.getElementById('states').value;
    //var hobbies1 = document.getElementById('hobbies1').value;
    var hobbies = "";
    var checkboxes = document.getElementsByName('hobbies');
    var vals = "";
    for (var i = 0, n = checkboxes.length; i < n; i++) {
        if (checkboxes[i].checked) {
            vals += "," + checkboxes[i].value;
        }
    }
    if (vals) vals = vals.substring(1);

    hobbies = vals;
    console.log('value of hobbies', hobbies);

    console.log("this from hobbies :: " + hobbies);

    
    // // Locat Storage
    var user_records = new Array();
    user_records = JSON.parse(localStorage.getItem("users")) ? JSON.parse(localStorage.getItem("users")) : []
    if (user_records.some((v) => { return v.email == email })) {
        alert("Duplicate Data")
    }
    else {
        user_records.push({
            "fname": fname,
            "lname": lname,
            "email": email,
            "mobile": mobile,
            "gender": gender,
            "adrs": adrs,
            "country": country,
            "states": states,
            "hobbies": hobbies
        });
        localStorage.setItem("users", JSON.stringify(user_records));
    }


    showTableData();



    // let user_records = new Array();
    // user_records = JSON.parse(localStorage.getItem("users"))
    // user_records={
    //     "fname": fname,
    //     "lname": lname,
    //     "email": email,
    //     "mobile": mobile,
    //     "gender": gender,
    //     "adrs": adrs,
    //     "country": country,
    //     "states": states,
    //     "hobbies1": hobbies1
    // };
    // // console.log('infoStorage');
    // localStorage.setItem('users', JSON.stringify(user_records));

    clearForm();





}

function showTableData(){
    console.log(localStorage.getItem("users"));
    var documents =  document.getElementById('tbl');
    var local_user = new Array();
    local_user = JSON.parse(localStorage.getItem("users")) ? JSON.parse(localStorage.getItem("users")) : [];
    console.log('hello lodu '+local_user);
    var tablejas ="";
    local_user.forEach(item => 
      
         tablejas =tablejas+ `<tr>
        <td>${item.fname}</td>
        <td>${item.lname}</td>
        <td>${item.email}</td>
        <td>${item.mobile}</td>
        <td>${item.gender}</td>
        <td>${item.adrs}</td>
        <td>${item.country}</td>
        <td>${item.states}</td>
        <td>${item.hobbies}</td>    
        
    </tr>`
  
        
        );

    document.getElementById('tbl').innerHTML += tablejas;    
 
}

// Clear Function
function clearForm() {

    document.getElementById("validation").reset();


}


// Validation use to call insert function
$(document).ready(
    function () {
        $('.submitform').on('click', function (event) {
            // console.log('test by jitu ', $("#validation").valid());
            if ($("#validation").valid()) {
                console.log('we are inside insert function');
                insert();
            }
        });
    });