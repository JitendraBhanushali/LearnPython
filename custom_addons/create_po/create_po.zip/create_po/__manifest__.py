# -*- coding: utf-8 -*-
{
    'name': "Create Po",
    'version': '1.0.0',
    'summary': "Create a Purchase Order",
    'sequence': -100,
    'description': "Create a Purchase Order",
    'author': "Intechual Solution",
    'website': "",
    'category': '',
    'depends': ['sale','purchase'],
    'data': [
        'views/sale_order_view.xml',
    ],
    'demo': [],
    'installable': True,
    'application': True,
    'assets': {},
    'license': 'LGPL-3',
}
