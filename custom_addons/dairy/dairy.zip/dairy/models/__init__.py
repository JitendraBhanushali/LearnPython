from . import seller
from . import res_partner