"""
Question:
Define a function which can compute the sum of two numbers.

Hints:
Define a function with two numbers as arguments. You can compute the sum in the function and return the value.


"""
a = int(input("Enter any number:- "))
b = int(input("Enter any number:- "))

""" ---------- Sum of two numbers --------"""
def sum1():
    c = a + b
    return c


print(sum1())
