"""
Define a function that can convert a integer into a string and print it in console.

Hints:

Use str() to convert a number to string.

"""

a = int(input("Enter value:- "))
""" ------------ Convert Number to string ------------------"""


def covert_str():
    b = str(a)
    print("Your String is:- ", b)


covert_str()
